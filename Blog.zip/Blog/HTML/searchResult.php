<html>
<head>
<meta charset="utf-8">
<title></title>
<style>
#index{
  background-image:url(../images/background_2.jpg);
  background-repeat: round;
  position:fixed;
  top:0px;
  left:0px;
  z-index:-1;
  opacity: 0.6;
  margin: 0;
  padding: 0;
  overflow: scroll;
}

#index-content{
  width: 66%;
  height: auto;
  position: absolute;
  top: 100px;
  left: 17%;
  margin: 0;
  padding: 0;
}

#index-content-searchresult-user{
  background: rgba(255, 255, 255, 0.5);
  width: 60%;
  padding: 0;
  margin: 0;
  height: 40px;
  position: relative;
  top: -20px;
  color: green;
  font-size: 20px;
  line-height: 40px;
}
#index-content-searchresult-user label{
  position: relative;
  left: 20px;
}
#index-content-searchresult-user input{
  position: relative;
  left: 80%;
}
#index-content-searchresult-blogpost,#index-content-searchresult-blogpost *{
  margin: 0;
  padding: 0;
}
#index-content-searchresult-blogpost{
  width: 60%;
  position: relative;
  top: 50px;
}
#index-content-searchresult-blogpost li{
  background: rgba(255, 255, 255, 0.5);
  list-style: none;
  border: 1px solid rgba(255, 255, 255, 0.5);
  margin-bottom: 20px;
  height: 100px;
}
#index-content-searchresult-blogpost li:hover{
  border: 1px solid orange;
}
#index-content-searchresult-blogpost li div *{
  position: relative;
  left: 20px;
  top: 10px;
}
#index-content-searchresult-blogpost li div{
  width: inherit;
  height: inherit;
}
#index-content-searchresult-blogpost li .title{
  color: blue;
  font-size: 30px;
  font-family: serif;
}
#index-content-searchresult-blogpost li span{
  width: 80px;
  height: 15px;
  top: 40px;
  left: 450px;
}
#index-content-searchresult-blogpost li .title:hover{
  color:orange;
}
#back{
  position: relative;
  top: 40px;
  left: 50%;
  font-size: 30px;
}
</style>
<script type="text/javascript" src="jquery-3.2.1.js"></script>
<script type="text/javascript">
/*$(document).ready(function(){
	var $screenWidth=$(window).width();
  var $screenHeight=$(window).height();
  $("#index").css({'width':$screenWidth,'height':$screenHeight});
  $(window).resize(function() {
    $screenWidth = $(window).width();
    $screenHeight = $(window).height();
    $("#index").css({'width':$screenWidth,'height':$screenHeight});
	});
  //浏览器自适应大小
});*/
</script>
<script type="text/javascript">
/*$(document).ready(function(){
	
	var flag = <?php include('searchData.php'); echo 1;?>;
	function checkFocus(){
		if(flag==1){
			$("#index-content-searchresult-user input").val("已关注");
			$("#index-content-searchresult-user input").attr('disabled','disabled');
		}
	}
	var TotalBlog=<?php include('searchData.php'); echo $searchname_article_num; ?>;
	alert(TotalBlog);
	function Showblogpost(){
		$("#index-content-searchresult-blogpost ul").empty();
		for(var i=0;i<TotalBlog;++i){
			$("#index-content-searchresult-blogpost ul").append('<li><div><label class="title">'+i+'</label><label>标签</label><br><span>评论：</span><span>点赞：</span></div></li>');
		}
	}
	checkFocus();
	Showblogpost();
});*/
	
</script>
</head>
<body>
	<div id="index">
		<div id="index-content">
			<div id="index-content-searchresult">
				<div id="index-content-searchresult-user">
					<label>
				
					</label>
					<form action="" method="post">
						<input type="submit" value="关注">
					</form>
				</div>
				<div id="index-content-searchresult-blogpost">
					<ul>
						<li>
							<div>
								<label class="title">标题</label>
								<label>标签</label><br>
								<span>评论：</span>
								<span>点赞：</span>
							</div>
						</li>
						<li>
							<div>
								<label class="title">标题</label>
								<label>标签</label><br>
								<span>评论：</span>
								<span>点赞：</span>
							</div>
						</li>
						<li>
						  <div>
							<label class="title">标题</label>
							<label>标签</label><br>
							<span>评论：</span>
							<span>点赞：</span>
						  </div>
						</li>
					</ul>
				</div>
			</div>
			<input id="back" type="button" value="返回" >
		</div>
	</div>
</body>
</html>
