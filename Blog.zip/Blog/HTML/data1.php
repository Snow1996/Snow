<?php
	$title=$_POST['title'];
	echo $title;
?>
