<?php
	include('data.php');
	$searchname=$_POST['searchkey'];
	$sqlb = "select user_name from user where user_name='$searchname'";
	$result = mysqli_query($con,$sqlb);
	$res = mysqli_num_rows($result);
	if($res <= 0){
		echo 'error';
	}else{
		echo $searchname;
	}
?>
