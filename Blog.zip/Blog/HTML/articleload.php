<?php
	include('conn.php');
	include('data.php');
	$title=$_POST['title'];
	$usersname=$_COOKIE["user"];
	$url=$usersname.'_'.$title.'.txt';
	echo file_get_contents("$url");
?>
