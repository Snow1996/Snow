<?php
	include("conn.php");
	$username = $_POST['username'];
	$passwd = $_POST['passwd'];
	$query  = "select user_name pwd from user where user_name = '$username' and user_pwd = '$passwd'";
	$result = mysqli_query($con,$query);
	if(mysqli_num_rows($result) >= 1){
		echo 'login success';
		header("location:http://120.25.220.178/Blog/HTML/visitor.php");
		setcookie("user", $username, time()+3600);
	}else{
		echo 'error';
	}
?>
