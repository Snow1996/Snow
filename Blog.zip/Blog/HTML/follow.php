<?php
	include('searchData.php');
	$sqld = "insert into user_attention values('$usersname', '$searchname')";
	$result=mysqli_query($con,$sqld);
	if($result != FALSE){
		echo '关注成功';
	}else{
		echo 'error';
	}	
?>
