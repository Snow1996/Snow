<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="../CSS/CSS.css" />
<title>NIIT学生个人博客</title>
<script type="text/javascript" src="../JS/jquery-3.2.1.js"></script>
<script type="text/javascript" src="../JS/windowChange.js"></script>


<script type="text/javascript">
//index.js
$(document).ready(function(){
  $("#index-head-list li").each(function(index,element){
    $(this).mouseenter(function(){
      $(this).css({'animation':'index-head-list-background 0.5s','-webkit-animation':'index-head-list-background 0.5s','font-size':'25px'});
      if(index===1){
        $("#index-classification").css('display','inline');
        $("#index-classification li").css({'animation':'index-classification 0.5s','-webkit-animation':'index-classification 0.5s'});
      }
    });
    $(this).mouseleave(function(){
      $(this).css({'animation':'index-head-list-backgroundback 0.5s','-webkit-animation':'index-head-list-backgroundback 0.5s','font-size':'20px'});
      if(index===1){
        $("#index-classification").css('display','none');
      }
    });
    if(index===1){
      $(this).hover(function(){
        $("#index-classification li").css('background','rgba(255,255,255,0.5)');
      });
    }
  });
  $("#index-classification").mouseenter(function(){
    $(this).css('display','inline');
    $("#index-classification li").css('background','rgba(255,255,255,0.5)');
  });
  $("#index-classification").mouseleave(function(){
    $(this).css('display','none');
  });
  $("#index-classification li").each(function(index,element){
    $(this).mouseenter(function(){
      $(this).css({'animation':'index-classification-background 0.5s','-webkit-animation':'index-classification-background 0.5s'});
    });
    $(this).mouseleave(function(){
      $(this).css({'animation':'index-classification-backgroundback 0.5s','-webkit-animation':'index-classification-backgroundback 0.5s'});
    });
  });
  $("#index-content-photos").mouseenter(function(){
    $("#index-content-photos-pre").css({'animation':'index-content-photos-pre 0.5s','-webkit-animation':'index-content-photos-pre 0.5s'});
    $("#index-content-photos-next").css({'animation':'index-content-photos-next 0.5s','-webkit-animation':'index-content-photos-next 0.5s'});
  });
  $("#index-content-photos").hover(function(){
    $("#index-content-photos-pre").css('left','0px');
    $("#index-content-photos-next").css('left','93%');
  },function(){
    $("#index-content-photos-pre").css('left','-7%');
    $("#index-content-photos-next").css('left','100%');
  });
  $("#index-content-photos").mouseleave(function(){
    $("#index-content-photos-pre").css({'animation':'index-content-photos-preback 0.5s','-webkit-animation':'index-content-photos-preback 0.5s'});
    $("#index-content-photos-next").css({'animation':'index-content-photos-nextback 0.5s','-webkit-animation':'index-content-photos-nextback 0.5s'});
  });
  var timer=null;
  var n=1;
  $("#index-content-photos-next p").click(function(){
    if(n>=4){}else{
      n++;
      $("#index-content-photos-footer label:first").html(n);
      var wid=parseFloat($("#index").css('width'))*0.66*0.6;
      var i=0;
      clearInterval(timer);
      timer=setInterval(function(){
        i++;
        $("#index-content-photos-img").css('left',parseFloat($("#index-content-photos-img").css('left'))-wid/100+'px');
        if(i==100) clearInterval(timer);
      },5);
    }
  });
  $("#index-content-photos-pre p").click(function(){
    if (n<=1) {}else {
      n--;
      $("#index-content-photos-footer label:first").html(n);
      var wid=parseFloat($("#index").css('width'))*0.66*0.6;
      var i=0;
      clearInterval(timer);
      timer=setInterval(function(){
        i++;
        $("#index-content-photos-img").css('left',parseFloat($("#index-content-photos-img").css('left'))+wid/100+'px');
        if(i==100) clearInterval(timer);
      },5);
    }
  });
});

</script>
<script type="text/javascript" >
//pagejump
$(document).ready(function(){
  $("#index-content>div:lt(6)").show(1000);
  $("#index-head-list li:first").click(function(){
    $("#index-content>div:visible").hide();
    $("#index-content>div:lt(6)").show(1000);
  });
  $("#index-classification li").each(function(index,element){
    $(this).click(function(){
      $("#index-content>div:visible").hide();
      $("#index-content>div").slice(3,8).show(1000);
      $("#index-content-tagname p").html($(this).html());
    });
  });
  $("#index-head-list li:eq(2)").click(function(){
    $("#index-content>div:visible").hide();
    $("#index-content>div").slice(3,6).show(1000);
    $("#index-content>div:eq(8)").show(1000);
  });
  $("#index-head-list li:eq(3)").click(function(){
    $("#index-content>div:visible").hide();
    $("#index-content>div").slice(3,6).show(1000);
    $("#index-content>div:eq(9)").show(1000);
  });
  $("#index-head-list li:eq(4)").click(function(){
    $("#index-content>div:visible").hide();
    $("#index-content>div").slice(3,6).show(1000);
    $("#index-content>div:eq(10)").show(1000);
  });
  $("#index-head-list li:eq(5)").click(function(){
    $("#index-content>div:visible").hide();
    $("#index-content>div").slice(3,6).show(1000);
    $("#index-content-ownblog").show(1000);
  });
  $("#index-content-privateletter-action label:first").click(function(){
    $("#index-content-privateletter>div:gt(0):visible").hide();
    $("#index-content-privateletter>div:eq(1)").show(1000);
  });
  $("#index-content-privateletter-action label:eq(1)").click(function(){
    $("#index-content-privateletter>div:gt(0):visible").hide();
    $("#index-content-privateletter>div:eq(2)").show(1000);
  });
  $("#index-content-privateletter-action label:eq(2)").click(function(){
    $("#index-content-privateletter>div:gt(0):visible").hide();
    $("#index-content-privateletter>div:eq(3)").show(1000);
  });
  $("#index-content-ownblog-action label:first").click(function(){
    $("#index-content-ownblog>div:gt(0):visible").hide();
    $("#index-content-ownblog>div:eq(1)").show(1000);
  });
  $("#index-content-ownblog-action label:eq(1)").click(function(){
    $("#index-content-ownblog>div:gt(0):visible").hide();
    $("#index-content-ownblog>div:eq(2)").show(1000);
  });
  $("#index-content-ownblog-action label:eq(2)").click(function(){
    $("#index-content-ownblog>div:gt(0):visible").hide();
    $("#index-content-ownblog>div:eq(3)").show(1000);
  });
  $(".toBlog").each(function(index,element){
    $(this).click(function(){
      $("#index-content>div:visible").hide();
      $("#index-content>div").slice(3,6).show(1000);
      $("#index-content-blog").show(1000);
      $("#index-content-blog-head-title").html($(this).html());
      $("#index-content-blog-head-author").html($(this).siblings(":eq(2)").html());
    });
  });
  $("#index-content-ownblog-blogpost .title,#index-content-searchresult-blogpost .title").each(function(index,element){
    $(this).click(function(){
      $("#index-content>div:visible").hide();
      $("#index-content>div").slice(3,6).show(1000);
      $("#index-content-blog").show(1000);
      $("#index-content-blog-head-title").html($(this).html());
      $("#index-content-blog-head-author").html('');
	  $.ajax({
		url:"articleload.php",
		data:{title:$(this).html()},
		type:"POST",
		dataType:"text",
		success:function(data){
		  alert(data);
			$("#index-content-blog-body p").html(data);
		}
	});
    });
  });
  $(".leavemessageact").each(function() {
    $(this).click(function(){
      $("#index-content-bloggerfocus-newmessage").show(1000);
    });
  });
  $(".letteract").each(function() {
    $(this).click(function(){
      $("#index-content>div:visible").hide();
      $("#index-content>div").slice(3,6).show(1000);
      $("#index-content>div:eq(10)").show(1000);
      $("#index-content-privateletter>div:gt(0):visible").hide();
      $("#index-content-privateletter>div:eq(3)").show(1000);
    });
  });
  $("#index-content-blog-action-comment").click(function(){
    $("#index-content-blog-newcomment").show(1000);
  });
});

</script>
</head>
<body>
  <div id="index">
    <div id="index-head">
      <span id="index-head-logo">
        <img  src="../images/logo1.png">
      </span>
    </div>
    <div id="index-head-list">
      <ul>
        <li>首页</li>
        <li id="index-head-list-classification">分类</li>
        <li>关注</li>
        <li>留言</li>
        <li>私信</li>
        <li>博文</li>
      </ul>
    </div>
    <div id="index-classification" style="display:none;">
      <ul>
        <li>热点</li>
        <li>社会</li>
        <li>娱乐</li>
        <li>科技</li>
        <li>汽车</li>
        <li>体育</li>
        <li>财经</li>
        <li>军事</li>
        <li>国际</li>
        <li>房产</li>
        <li>其他</li>
      </ul>
    </div>
    <div id="index-content">
      <div id="index-content-photos" style="display:none;">
        <div class="pointer" id="index-content-photos-pre"><p><</p></div>
        <div id="index-content-photos-img">
          <img class="photos" src="../images/logo.jpg">
          <img class="photos" src="../images/logo.jpg">
          <img class="photos" src="../images/logo.jpg">
          <img class="photos" src="../images/logo.jpg">
        </div>
        <div class="pointer" id="index-content-photos-next"><p>></p></div>
        <div id="index-content-photos-footer"><p><label>1</label>/<label>4</label></p></div>
      </div>
      <div id="index-content-newest" style="display:none;">
        <p>最新文章</p>
      </div>
      <div id="index-content-newestpost" style="display:none;">
        <ul>
          <li>
            <div>
              <label class="title toBlog">标题1</label>
              <label>标签</label><br>
              <span>作者：</span>
              <span>评论：</span>
              <span>点赞：</span>
            </div>
          </li>
          <li>
            <div>
              <label class="title toBlog">标题2</label>
              <label>标签</label><br>
              <span>作者：</span>
              <span>评论：</span>
              <span>点赞：</span>
            </div>
          </li>
          <li>
            <div>
              <label class="title toBlog">标题</label>
              <label>标签</label><br>
              <span>作者：</span>
              <span>评论：</span>
              <span>点赞：</span>
            </div>
          </li>
          <li>
            <div>
              <label class="title toBlog">标题</label>
              <label>标签</label><br>
              <span>作者：</span>
              <span>评论：</span>
              <span>点赞：</span>
            </div>
          </li>
          <li>
            <div>
              <label class="title toBlog">标题</label>
              <label>标签</label><br>
              <span>作者：</span>
              <span>评论：</span>
              <span>点赞：</span>
            </div>
          </li>
          <li>
            <div>
              <label class="title toBlog">标题</label>
              <label>标签</label><br>
              <span>作者：</span>
              <span>评论：</span>
              <span>点赞：</span>
            </div>
          </li>
          <li>
            <div>
              <label class="title toBlog">标题</label>
              <label>标签</label><br>
              <span>作者：</span>
              <span>评论：</span>
              <span>点赞：</span>
            </div>
          </li>
          <li>
            <div>
              <label class="title toBlog">标题</label>
              <label>标签</label><br>
              <span>作者：</span>
              <span>评论：</span>
              <span>点赞：</span>
            </div>
          </li>
          <li>
            <div>
              <label class="title toBlog">标题</label>
              <label>标签</label><br>
              <span>作者：</span>
              <span>评论：</span>
              <span>点赞：</span>
            </div>
          </li>
          <li>
            <div>
              <label class="title toBlog">标题</label>
              <label>标签</label><br>
              <span>作者：</span>
              <span>评论：</span>
              <span>点赞：</span>

            </div>
          </li>
        </ul>
      </div>
      <div id="index-content-visitor" style="display:none;">
        <div id="index-content-visitor-baseinfo">
          <label id="index-content-visitor-baseinfo-username">
			<?php
				include('data.php');
				echo $usersname;
			?>
		  </label><br>
          <label id="index-content-visitor-baseinfo-email">
			<?php
				include('data.php');
				echo $email;
			?>
		  </label>
        </div>
        <div id="index-content-visitor-info">
          <ul>
            <li class="haveborder">
              <label class="dynamicnum">
				<?php
					include('data.php');
					echo $attention_num;
				?>
			  </label><br>
              <label class="dynamic">关注</label>
            </li>
            <li class="haveborder">
              <label class="dynamicnum">
			  <?php
				include('data.php');
				echo $flowers;
			  ?>
			  </label><br>
              <label class="dynamic">鲜花</label>
            </li>
            <li>
              <label class="dynamicnum">
			  <?php
				include('data.php');
				echo $fans_num;
			  ?>
			  </label><br>
              <label class="dynamic">粉丝</label>
            </li>
          </ul>
        </div>
      </div>
      <div id="index-content-searchblogger" style="display:none;">
			<form action="search.php" method="post">
			    <input id="index-content-searchblogger-text" type="text" name="searchkey">
			    <input id="index-content-searchblogger-submit" type="submit" value="搜索用户">
			</form>
	    </div>
      <div id="index-content-blogrecommend" style="display:none;">
        <div id="index-content-blogrecommend-head"><label>推荐博文</label></div>
        <div id="index-content-blogrecommend-body">
          <ul>
            <li>
              <label class="blogrecommendtitle toBlog">标题</label><br>
              <label>标签</label><br>
              <span>作者：</span>
              <span>点赞：</span>
            </li>
            <li>
              <label class="blogrecommendtitle toBlog">标题</label><br>
              <label>标签</label><br>
              <span>作者：</span>
              <span>点赞：</span>
            </li>
            <li>
              <label class="blogrecommendtitle toBlog">标题</label><br>
              <label>标签</label><br>
              <span>作者：</span>
-              <span>点赞：</span>
            </li>
            <li>
              <label class="blogrecommendtitle toBlog">标题</label><br>
              <label>标签</label><br>
              <span>作者：</span>
              <span>点赞：</span>
            </li>
          </ul>
        </div>
      </div>
      <div id="index-content-tagname" style="display:none;">
        <p>标签：</p>
      </div>
      <div id="index-content-tagpost" style="display:none;">
        <ul>
          <li>
            <div>
              <label class="title toBlog">标题</label>
              <label>标签</label><br>
              <span>作者：</span>
              <span>评论：</span>
              <span>点赞：</span>
            </div>
          </li>
          <li>
            <div>
              <label class="title toBlog">标题</label>
              <label>标签</label><br>
              <span>作者：</span>
              <span>评论：</span>
              <span>点赞：</span>
            </div>
          </li>
          <li>
            <div>
              <label class="title toBlog">标题</label>
              <label>标签</label><br>
              <span>作者：</span>
              <span>评论：</span>
              <span>点赞：</span>
            </div>
          </li>
        </ul>
      </div>
      <div id="index-content-bloggerfocus" style="display:none;">
        <ul>
          <li>
            <div>
              <label class="title">博主</label>
              <label>邮箱</label><br>
              <span>打赏：</span>
              <span class="leavemessageact">留言：</span>
              <span class="letteract">私信</span>
            </div>
          </li>
          <li>
            <div>
              <label class="title">博主</label>
              <label>邮箱</label><br>
              <span>打赏：</span>
              <span class="leavemessageact">留言：</span>
              <span class="letteract">私信</span>
            </div>
          </li>
          <li>
            <div>
              <label class="title">博主</label>
              <label>邮箱</label><br>
              <span>打赏：</span>
              <span class="leavemessageact">留言：</span>
              <span class="letteract">私信</span>
            </div>
          </li>
        </ul>
        <div id="index-content-bloggerfocus-newmessage" style="display:none;">
          <form>
            <textarea value="" rows=10 cols=40 onpropertychange="this.style.posHeight=this.scrollHeight"></textarea>
            <input id="index-content-bloggerfocus-newmessage-submit" type="submit" value="发送">
          </form>
        </div>
      </div>
      <div id="index-content-messageleaving" style="display:none;">
        <ul>
          <li>
            <div>
              <label>留言内容</label><br>
              <span>留言人：</span>
            </div>
          </li>
          <li>
            <div>
              <label>留言内容</label><br>
              <span>留言人：</span>
            </div>
          </li>
          <li>
            <div>
              <label>留言内容</label><br>
              <span>留言人：</span>
            </div>
          </li>
        </ul>

      </div>
      <div id="index-content-privateletter" style="display:none;">
        <div id="index-content-privateletter-action">
          <ul>
            <li class="haveborder">
              <label>收件箱</label>
            </li>
            <li class="haveborder">
              <label>发件箱</label>
            </li>
            <li>
              <label>写私信</label>
            </li>
          </ul>
        </div>
        <div id="index-content-privateletter-inbox" >
          <ul>
            <li>
              <div>
                <label>主题</label><br>
                <span>发件人：</span>
              </div>
            </li>
            <li>
              <div>
                <label>主题</label><br>
                <span>发件人：</span>
              </div>
            </li>
            <li>
              <div>
                <label>主题</label><br>
                <span>发件人：</span>
              </div>
            </li>
          </ul>
        </div>
        <div id="index-content-privateletter-outbox" style="display:none;">
          <ul>
            <li>
              <div>
                <label>主题</label><br>
                <span>收件人：</span>
              </div>
            </li>
            <li>
              <div>
                <label>主题</label><br>
                <span>收件人：</span>
              </div>
            </li>
            <li>
              <div>
                <label>主题</label><br>
                <span>收件人：</span>
              </div>
            </li>
          </ul>
        </div>
        <div id="index-content-privateletter-newletter" style="display:none;">
          <form action="" method="post">
            <table>
              <tr>
                <td class="label"><label>主题：</label></td>
                <td class="input"><input type="text" value=""><br></td>
              </tr>
              <tr>
                <td class="label"><label>收件人：</label></td>
                <td class="input"><input type="text" value=""><br></td>
              </tr>
              <tr id="index-content-privateletter-newletter-3tr">
                <td class="label"><label>正文：</label></td>
                <td class="input"><textarea value="" rows=20 cols=70 onpropertychange="this.style.posHeight=this.scrollHeight"></textarea></td>
              </tr>
            </table>
            <input id="index-content-privateletter-newletter-submit" type="submit" value="发送">
          </form>
        </div>
      </div>
      <div id="index-content-blog" style="display:none;">
        <div id="index-content-blog-head">
          <label id="index-content-blog-head-title">标题</label><br>
          <label id="index-content-blog-head-author">作者</label>
        </div>
        <div id="index-content-blog-body">
          <p>内容</p>
        </div>
        <div id="index-content-blog-action">
          <ul>
            <li class="haveborder"><label>点赞</label></li>
            <li class="haveborder"><label>打赏作者</label></li>
            <li class="haveborder"><label>关注作者</label></li>
            <li id="index-content-blog-action-comment"><label>评论</label></li>
          </ul>
        </div>
        <div id="index-content-blog-comment">
          <label>评论区<label>
        </div>
        <div id="index-content-blog-commentcontent">
          <ul>
            <li><label>用户1</label><label>:</label><label>评论一</label></li>
            <li><label>用户1</label><label>:</label><label>评论一</label></li>
            <li><label>用户1</label><label>:</label><label>评论一</label></li>
          </ul>
        </div>
        <div id="index-content-blog-newcomment" style="display:none;">
          <form>
            <textarea value="" rows=10 cols=40 onpropertychange="this.style.posHeight=this.scrollHeight"></textarea>
            <input id="index-content-blog-newcomment-submit" type="submit" value="发送">
          </form>
        </div>
      </div>
      <div id="index-content-ownblog" style="display:none;">
        <div id="index-content-ownblog-action">
          <ul>
            <li class="haveborder">
              <label>已发博文</label>
            </li>
            
            <li>
              <label>新建博文</label>
            </li>
          </ul>
        </div>
        <div id="index-content-ownblog-blogpost">
          <ul>
            <li>
              <div>
                <label class="title">标题1</label>
                <label>标签</label><br>
                <span>评论：</span>
                <span>点赞：</span>
              </div>
            </li>
          </ul>
		  <script>
			var totalBlog=<?php include('data.php'); echo $user_article_num;?>;
			function showblogpost(){
				$("#index-content-ownblog-blogpost ul").empty();
				for(var i=0;i<totalBlog;i++){
					$("#index-content-ownblog-blogpost ul").append('<li><div><label class="title toBlog">'+i+'</label><label>标签</label><br><span>评论：</span><span>点赞：</span></div></li>');
				}
			}
			showblogpost();
		  </script>
        </div>
        <div id="index-conrent-ownblog-needcheck" style="display:none;"></div>
        <div id="index-content-ownblog-newblog" style="display:none;">
          <form action="articleUp.php" method="post">
            <table>
              <tr>
                <td class="label"><label>标题：</label></td>
                <td class="input"><input type="text" name="title"><br></td>
              </tr>
              <tr id="index-content-ownblog-newblog-3tr">
                <td class="label"><label>正文：</label></td>
                <td class="input"><textarea rows=20 cols=70 onpropertychange="this.style.posHeight=this.scrollHeight" name="ac"></textarea></td>
              </tr>
            </table>
            <input id="index-content-ownblog-newblog-submit" type="submit">
          </form>
        </div>
      </div>
      <div id="index-content-searchresult" style="display:none;">
        <div id="index-content-searchresult-user">
          <label>用户名：</label>
          <input type="button" value="关注">
        </div>
        <div id="index-content-searchresult-blogpost">
          <ul>
            <li>
              <div>
                <label class="title">标题</label>
                <label>标签</label><br>
                <span>评论：</span>
                <span>点赞：</span>
              </div>
            </li>
            <li>
              <div>
                <label class="title">标题</label>
                <label>标签</label><br>
                <span>评论：</span>
                <span>点赞：</span>
              </div>
            </li>
            <li>
              <div>
                <label class="title">标题</label>
                <label>标签</label><br>
                <span>评论：</span>
                <span>点赞：</span>
              </div>
            </li>
          </ul>
		  <script>
			var TotalBlog=<?php include('search.php'); echo $searchname_article; ?>;
			function Showblogpost(){
				alert(TotalBlog);
				$("#index-content-searchresult-blogpost ul").empty();
				for(var i=0;i<TotalBlog;i++){
					$("#index-content-searchresult-blogpost ul").append('<li><div><label class="title">'+i+'</label><label>标签</label><br><span>评论：</span><span>点赞：</span></div></li>');
				}
			}
			Showblogpost();
      }
		 </script>
        </div>
		
      </div>
    </div>
  </div>
</body>
</html>
