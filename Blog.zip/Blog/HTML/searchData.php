<?php
	include('data.php');
	$searchname=$_COOKIE['search'];	
	$sqlc = "select * from article where user_name='$searchname'";
	$result=mysqli_query($con,$sqlc);
	$searchname_article_num=mysqli_num_rows($result);
	//$article_contents=array();
	//for($i=0; i<$searchname_article_num; ++$i){
	//	$searchname_article_num[] = file_get_contents("'$searchname'.'_'.'$i'.'.txt'");
	//}
	$sqlc2 = "select * from user_attention where user_name='$usersname' and attention_name='$searchname'";
	$bb=111;
	$result = mysqli_query($con,$sqlc2);
	if(mysqli_num_rows($result) == 0){
		$bb = 0;
	}else{
		$bb = 1;
	}

?>
