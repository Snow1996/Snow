<?php

$con=mysqli_connect("localhost","root","12345") or die("mysql link failed");
mysqli_select_db($con,'legend_blog')or die("dblink failed");
//mysqli_query('set names utf-8');

?>
