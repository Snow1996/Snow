<?php
	include('data.php');
	$article_content = $_POST['ac'];
	$name=$usersname.'_'.$user_article_num.'.txt';
	$title=$_POST['title'];
	$s=file_put_contents($name,$article_content);
	$timea = date('Y-m-d H:i:s');	
	$sqla = "insert into article(article_name,article_time,article_click,article_support,user_name,article_title) values('$name', '$timea', 0, 0, '$usersname', '$title')";
	$result=mysqli_query($con,$sqla);
	if($result!=FALSE){
		echo $s;
	}else{
		echo 'error';
	}
?>
