<?php
	include('data.php');
	$searchname=$_POST['searchkey'];
	$sqlb = "select user_name from user where user_name='$searchname'";
	$result1 = mysqli_query($con,$sqlb);
	$res1 = mysqli_num_rows($result1);
	if($res1 == 0){
		echo '无该用户';
	}else if($usersname == $searchname){
		echo '不能自己搜索自己';
	}else{
		setcookie("search", $searchname, time()+3600);
		//echo $searchname;
		header("location:http://120.25.220.178/Blog/HTML/searchResult2.php");
	}

?>
