<?php
	header("Content-Type:text/html;Charset=utf-8");
	include("conn.php");
	$username = $_POST['username'];
	$passwd = $_POST['passwd'];
	$useremail = $_POST['email'];
	$gender = $_POST['gender'];
	$query  = "select user_name from user where user_name = '$username'";
	$time = date('Y-m-d H:i:s');
	$last_time = $time;
	$result = mysqli_query($con,$query);
	if(mysqli_num_rows($result) == 0){
		$query = "insert into user(user_name,user_pwd,user_sex,user_email,user_register_time,user_last_update_time) values('$username', '$passwd', '$gender', '$useremail', '$time', '$last_time')";
		$result2=mysqli_query($con,$query);
		if($result2 == FALSE){
			echo 'insert failed';
		}
		echo 'register succeed';
	}else{
		echo 'Already registered';
	}
	
?>
