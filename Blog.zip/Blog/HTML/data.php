<?php
	include('conn.php');
	$usersname=$_COOKIE["user"];
	
	$sql1 = "select user_email from user where user_name='$usersname'";
	$result = mysqli_query($con,$sql1);		
	$res = mysqli_fetch_row($result);
	$email = $res[0];
	
	$sql2 = "select reward_amound from user_reward where reward_user_name = '$usersname'";
	$result = mysqli_query($con,$sql2);
	$res = mysqli_fetch_row($result);
	$flowers = $res[0];
	
	$sql3 = "select user_name from user_attention where user_name='$usersname'";
	$result = mysqli_query($con,$sql3);
	$attention_num = mysqli_num_rows($result);
	
	$sql4 = "select * from user_attention where attention_name='$usersname'";
	$result = mysqli_query($con,$sql4);
	$fans_num = mysqli_num_rows($result);

	$sql5 = "select * from article where user_name='$usersname'";
	$result = mysqli_query($con,$sql5);
	$user_article_num = mysqli_num_rows($result);

//	$sql6 = "select article_title from article where user_name='$usersname'";
//	$result = mysqli_query($con,$sql6);
//	$arr=array();
//	while($ar=mysqli_fetch_array($result)){
//		$arr[]=$ar;
//	}
//	$article_titles=array();
//	for($i=0; $i<$user_article_num ;++$i){
//		$article_titles[]=$arr[$i];
//	}
//	$a=array($arr[0], $arr[1], $arr[2]);
//	file_put_contents("aaaa.txt",$article_titles[2]);
//	print_r($article_titles[0]);
?>
















