$(document).ready(function(){
  $("#index-head-list li").each(function(index,element){
    $(this).mouseenter(function(){
      $(this).css({'animation':'index-head-list-background 0.5s','-webkit-animation':'index-head-list-background 0.5s','font-size':'25px'});
      if(index===1){
        $("#index-classification").css('display','inline');
        $("#index-classification li").css({'animation':'index-classification 0.5s','-webkit-animation':'index-classification 0.5s'});
      }
    });
    $(this).mouseleave(function(){
      $(this).css({'animation':'index-head-list-backgroundback 0.5s','-webkit-animation':'index-head-list-backgroundback 0.5s','font-size':'20px'});
      if(index===1){
        $("#index-classification").css('display','none');
      }
    });
    if(index===1){
      $(this).hover(function(){
        $("#index-classification li").css('background','rgba(255,255,255,0.5)');
      });
    }
  });
  $("#index-classification").mouseenter(function(){
    $(this).css('display','inline');
    $("#index-classification li").css('background','rgba(255,255,255,0.5)');
  });
  $("#index-classification").mouseleave(function(){
    $(this).css('display','none');
  });
  $("#index-classification li").each(function(index,element){
    $(this).mouseenter(function(){
      $(this).css({'animation':'index-classification-background 0.5s','-webkit-animation':'index-classification-background 0.5s'});
    });
    $(this).mouseleave(function(){
      $(this).css({'animation':'index-classification-backgroundback 0.5s','-webkit-animation':'index-classification-backgroundback 0.5s'});
    });
  });
  $("#index-content-photos").mouseenter(function(){
    $("#index-content-photos-pre").css({'animation':'index-content-photos-pre 0.5s','-webkit-animation':'index-content-photos-pre 0.5s'});
    $("#index-content-photos-next").css({'animation':'index-content-photos-next 0.5s','-webkit-animation':'index-content-photos-next 0.5s'});
  });
  $("#index-content-photos").hover(function(){
    $("#index-content-photos-pre").css('left','0px');
    $("#index-content-photos-next").css('left','93%');
  },function(){
    $("#index-content-photos-pre").css('left','-7%');
    $("#index-content-photos-next").css('left','100%');
  });
  $("#index-content-photos").mouseleave(function(){
    $("#index-content-photos-pre").css({'animation':'index-content-photos-preback 0.5s','-webkit-animation':'index-content-photos-preback 0.5s'});
    $("#index-content-photos-next").css({'animation':'index-content-photos-nextback 0.5s','-webkit-animation':'index-content-photos-nextback 0.5s'});
  });
  var timer=null;
  var n=1;
  $("#index-content-photos-next p").click(function(){
    if(n>=4){}else{
      n++;
      $("#index-content-photos-footer label:first").html(n);
      var wid=parseFloat($("#index").css('width'))*0.66*0.6;
      var i=0;
      clearInterval(timer);
      timer=setInterval(function(){
        i++;
        $("#index-content-photos-img").css('left',parseFloat($("#index-content-photos-img").css('left'))-wid/100+'px');
        if(i==100) clearInterval(timer);
      },5);
    }
  });
  $("#index-content-photos-pre p").click(function(){
    if (n<=1) {}else {
      n--;
      $("#index-content-photos-footer label:first").html(n);
      var wid=parseFloat($("#index").css('width'))*0.66*0.6;
      var i=0;
      clearInterval(timer);
      timer=setInterval(function(){
        i++;
        $("#index-content-photos-img").css('left',parseFloat($("#index-content-photos-img").css('left'))+wid/100+'px');
        if(i==100) clearInterval(timer);
      },5);
    }
  });
  //var totalBlog=<?php include('../HTML/data.php'); echo $user_article_num;?>;
  $.ajax({
	  url:"../HTML/article_num.php",
	  type:"POST",
	  dataType:"json",
	  error:function(){
		  alert('error');
	  },
	  success:function(data){
		  alert(data);
		$("#index-content-newestpost ul").empty();
		for(var i=0;i<data.length();i++){
		 $("#index-content-newestpost ul").append('<li>
            <div>
              <label class="title toBlog">标题1</label>
              <label>标签</label><br>
              <span>评论：</span>
              <span>点赞：</span>
            </div>
          </li>') ;
		}
	  }
  });
});
