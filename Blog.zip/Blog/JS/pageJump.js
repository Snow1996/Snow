$(document).ready(function(){
  $("#index-content>div:lt(5)").show(1000);
  $("#index-head-list li:first").click(function(){
    $("#index-content>div:visible").hide();
    $("#index-content>div:lt(5)").show(1000);
  });
  $("#index-classification li").each(function(index,element){
    $(this).click(function(){
      $("#index-content>div:visible").hide();
      $("#index-content>div").slice(3,7).show(1000);
      $("#index-content-tagname p").html($(this).html());
    });
  });
  $("#index-head-list li:eq(2)").click(function(){
    $("#index-content>div:visible").hide();
    $("#index-content>div").slice(3,5).show(1000);
    $("#index-content>div:eq(7)").show(1000);
  });
  $("#index-head-list li:eq(3)").click(function(){
    $("#index-content>div:visible").hide();
    $("#index-content>div").slice(3,5).show(1000);
    $("#index-content>div:eq(8)").show(1000);
  });
  $("#index-head-list li:eq(4)").click(function(){
    $("#index-content>div:visible").hide();
    $("#index-content>div").slice(3,5).show(1000);
    $("#index-content>div:eq(9)").show(1000);
  });
  $("#index-head-list li:eq(5)").click(function(){
    $("#index-content>div:visible").hide();
    $("#index-content>div").slice(3,5).show(1000);
    $("#index-content-ownblog").show(1000);
	alert(1);
	/*$.ajax({
	  url:"../HTML/article_num.php",
	  type:"POST",
	  dataType:"json",
	  error:function(){
		  alert('error');
	  },
	  success:function(data){
		  alert(data);
		$("#index-content-newestpost ul").empty();
		for(var i=0;i<getJsonLength(data);i++){
		 $("#index-content-newestpost ul").append('<li>
            <div>
              <label class="title toBlog">标题1</label>
              <label>标签</label><br>
              <span>评论：</span>
              <span>点赞：</span>
            </div>
          </li>');
		}
	  }
	});*/
  });
  function getJsonLength(json){
	  var a=0;
	  for(var i in json){
		  a++;
	  }
	  return a;
  }
  $("#index-content-privateletter-action label:first").click(function(){
    $("#index-content-privateletter>div:gt(0):visible").hide();
    $("#index-content-privateletter>div:eq(1)").show(1000);
  });
  $("#index-content-privateletter-action label:eq(1)").click(function(){
    $("#index-content-privateletter>div:gt(0):visible").hide();
    $("#index-content-privateletter>div:eq(2)").show(1000);
  });
  $("#index-content-privateletter-action label:eq(2)").click(function(){
    $("#index-content-privateletter>div:gt(0):visible").hide();
    $("#index-content-privateletter>div:eq(3)").show(1000);
  });
  $("#index-content-ownblog-action label:first").click(function(){
    $("#index-content-ownblog>div:gt(0):visible").hide();
    $("#index-content-ownblog>div:eq(1)").show(1000);
  });
  $("#index-content-ownblog-action label:eq(1)").click(function(){
    $("#index-content-ownblog>div:gt(0):visible").hide();
    $("#index-content-ownblog>div:eq(2)").show(1000);
  });
  $("#index-content-ownblog-action label:eq(2)").click(function(){
    $("#index-content-ownblog>div:gt(0):visible").hide();
    $("#index-content-ownblog>div:eq(3)").show(1000);
  });
  $(".toBlog").each(function(index,element){
    $(this).click(function(){
      $("#index-content>div:visible").hide();
      $("#index-content>div").slice(3,5).show(1000);
      $("#index-content-blog").show(1000);
      $("#index-content-blog-head-title").html($(this).html());
      $("#index-content-blog-head-author").html($(this).siblings(":eq(2)").html());
    });
  });
  $("#index-content-ownblog-blogpost .title").each(function(index,element){
    $(this).click(function(){
      $("#index-content>div:visible").hide();
      $("#index-content>div").slice(3,5).show(1000);
      $("#index-content-blog").show(1000);
      $("#index-content-blog-head-title").html($(this).html());
      $("#index-content-blog-head-author").html('');
    });
  });
  $(".leavemessageact").each(function() {
    $(this).click(function(){
      $("#index-content-bloggerfocus-newmessage").show(1000);
    });
  });
  $(".letteract").each(function() {
    $(this).click(function(){
      $("#index-content>div:visible").hide();
      $("#index-content>div").slice(3,5).show(1000);
      $("#index-content>div:eq(9)").show(1000);
      $("#index-content-privateletter>div:gt(0):visible").hide();
      $("#index-content-privateletter>div:eq(3)").show(1000);
    });
  });
  $("#index-content-blog-action-comment").click(function(){
    $("#index-content-blog-newcomment").show(1000);
  });
});
