$(document).ready(function(){
	var $screenWidth=$(window).width();
  var $screenHeight=$(window).height();
  $("#index").css({'width':$screenWidth,'height':$screenHeight});
  $(window).resize(function() {
    $screenWidth = $(window).width();
    $screenHeight = $(window).height();
    $("#index").css({'width':$screenWidth,'height':$screenHeight});
});
  //浏览器自适应大小
});
