-- MySQL dump 10.13  Distrib 5.7.18, for Linux (x86_64)
--
-- Host: localhost    Database: legend_blog
-- ------------------------------------------------------
-- Server version	5.7.18-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `about_blog`
--

DROP TABLE IF EXISTS `about_blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `about_blog` (
  `blog_description` varchar(255) NOT NULL,
  `blog_name` varchar(36) NOT NULL,
  `blog_title` varchar(128) NOT NULL,
  `blog_id` int(8) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`blog_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `about_blog`
--

LOCK TABLES `about_blog` WRITE;
/*!40000 ALTER TABLE `about_blog` DISABLE KEYS */;
INSERT INTO `about_blog` VALUES ('Some about Mike','Mike\'s blog','Hello World',1,'mike'),('More about Mike','Mike\'s second blog','Hello World!!',2,'mike'),('About Amy\'s life','Amy\'s blog','Hello Amy',3,'Amy'),('It\'s Nancy','Meet Nancy','Test Nancy',4,'Nancy');
/*!40000 ALTER TABLE `about_blog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article` (
  `article_name` varchar(128) CHARACTER SET utf8 NOT NULL,
  `article_time` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  `article_click` int(10) NOT NULL,
  `article_support` int(3) NOT NULL DEFAULT '0',
  `user_name` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `article_title` varchar(64) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES ('Amy_1.txt','2017-05-17 19:25:58',0,0,'Amy',''),('Amy_0.txt','2017-05-17 19:25:03',0,0,'Amy',''),('mike_0.txt','2017-05-16 22:19:07',20,25,'mike','PHP'),('mike_2.txt','2017-05-16 22:31:38',40,2,'mike','C++'),('Amy_2.txt','2017-05-17 19:26:37',0,0,'Amy',''),('mike_3.txt','2017-05-17 21:08:54',0,0,'mike','你好'),('mike_4.txt','2017-05-18 10:56:39',0,0,'mike','éƒ¨åˆ†çš„æ•°æ®åº“'),('$name','$timea',0,0,'$usersname','$title'),('mike_5.txt','2017-05-18 11:07:19',0,0,'mike','ä¼¼çš„çŠ¯å¾—ä¸Šå‘ç”Ÿ'),('mike_6.txt','2017-05-18 11:12:12',0,0,'mike','\"sdfsadaså‘å°„ç‚¹\"'),('mike_7.txt','2017-05-18 11:12:13',0,0,'mike','\"sdfsadaså‘å°„ç‚¹\"'),('mike_8.txt','2017-05-18 11:13:48',0,0,'mike','\"qqqæ˜¯å¦\"'),('mike_9.txt','2017-05-18 11:16:25',0,0,'mike','\"qqqæ˜¯å¦\"'),('_0.txt','2017-05-19 17:37:57',0,0,'',''),('_3.txt','2017-05-19 18:42:03',0,0,'','aasdasdas'),('_1.txt','2017-05-19 18:19:12',0,0,'',''),('mike_1.txt','2017',0,0,'mike','大事发生的'),('_2.txt','2017-05-19 18:19:32',0,0,'','');
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article_tag`
--

DROP TABLE IF EXISTS `article_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article_tag` (
  `a_t_id` int(5) NOT NULL,
  `article_id` int(5) NOT NULL,
  `tag_id` int(8) NOT NULL,
  PRIMARY KEY (`a_t_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_tag`
--

LOCK TABLES `article_tag` WRITE;
/*!40000 ALTER TABLE `article_tag` DISABLE KEYS */;
INSERT INTO `article_tag` VALUES (1,1,2),(2,2,4),(3,1,3),(4,6,2),(5,3,1),(6,4,4),(7,5,3);
/*!40000 ALTER TABLE `article_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `secret_message`
--

DROP TABLE IF EXISTS `secret_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `secret_message` (
  `secret_id` int(8) NOT NULL AUTO_INCREMENT,
  `message_stay_time` varchar(64) DEFAULT NULL,
  `message_content` varchar(255) NOT NULL,
  `user_name` varchar(32) DEFAULT NULL,
  `receive_name` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`secret_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `secret_message`
--

LOCK TABLES `secret_message` WRITE;
/*!40000 ALTER TABLE `secret_message` DISABLE KEYS */;
INSERT INTO `secret_message` VALUES (1,'2002','Nice to meet you','mike','Amy'),(2,'2001','Lucky to see you','Amy','mike'),(3,'2004','Call me soon','mike','John'),(4,'2003','Good article','Amy','test'),(5,'2010','Not very good','Nancy','mike'),(6,'2003','Nice to meet you','John','Nancy');
/*!40000 ALTER TABLE `secret_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensitive_word`
--

DROP TABLE IF EXISTS `sensitive_word`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensitive_word` (
  `sw_id` int(8) NOT NULL AUTO_INCREMENT,
  `sw_word` varchar(32) NOT NULL,
  PRIMARY KEY (`sw_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensitive_word`
--

LOCK TABLES `sensitive_word` WRITE;
/*!40000 ALTER TABLE `sensitive_word` DISABLE KEYS */;
INSERT INTO `sensitive_word` VALUES (2,'你好'),(3,'习近平'),(4,'萨德'),(5,'屁'),(6,'死'),(7,'傻'),(8,'屌'),(9,'操'),(10,'日'),(1,'呆');
/*!40000 ALTER TABLE `sensitive_word` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stay_message`
--

DROP TABLE IF EXISTS `stay_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stay_message` (
  `stay_id` int(5) NOT NULL AUTO_INCREMENT,
  `stay_content` varchar(255) NOT NULL,
  `stay_time` varchar(64) DEFAULT NULL,
  `user_name` varchar(32) DEFAULT NULL,
  `stay_user_name` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`stay_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stay_message`
--

LOCK TABLES `stay_message` WRITE;
/*!40000 ALTER TABLE `stay_message` DISABLE KEYS */;
INSERT INTO `stay_message` VALUES (1,'Want to copy from you','20171212','mike','Amy'),(2,'Want to contact you','20160516','Amy','John'),(3,'Good Article','20170101','Nancy','test'),(4,'I have better things','20170510','John','mike');
/*!40000 ALTER TABLE `stay_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag` (
  `tag_id` int(8) NOT NULL,
  `tag_name` varchar(32) NOT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (1,'society'),(2,'hot pot'),(3,'Technology'),(4,'Car'),(5,'PE'),(6,'Finance'),(7,'Military'),(8,'International'),(9,'Property'),(10,'Others');
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_name` varchar(32) NOT NULL,
  `user_pwd` varchar(32) NOT NULL,
  `user_sex` varchar(32) NOT NULL,
  `user_email` varchar(64) NOT NULL,
  `user_register_time` varchar(64) DEFAULT NULL,
  `user_last_update_time` varchar(64) DEFAULT NULL,
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('test','test','male','1@qq.com','12052017','12052017'),('mike','mike12345','man','mike123@qq.com','2015','1999'),('Amy','Amy12345','femal','Amy123@qq.com','2015','1999'),('Nancy','Nancyhello','femal','Nancy123456@qq.com','2013','1999'),('John','Johnman','male','John789789@qq.com','2011','1999'),('Blogger1','123123','female','123123@qq.com','20170512','20170513'),('Manager1','456456','female','456456@qq.com','20170510','20170511'),('zzz','passwd','male','11@qq.com','100','200'),('sss','aaa111!!!','male','11@qq.com','2017-05-16 11:42:13','2017-05-16 11:42:13'),('','','male','','2017-05-16 20:13:10','2017-05-16 20:13:10'),('syj','syj123!!!','male','aaaaa@1.com','2017-05-19 17:27:29','2017-05-19 17:27:29');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_attention`
--

DROP TABLE IF EXISTS `user_attention`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_attention` (
  `user_name` varchar(32) DEFAULT NULL,
  `attention_name` varchar(32) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_attention`
--

LOCK TABLES `user_attention` WRITE;
/*!40000 ALTER TABLE `user_attention` DISABLE KEYS */;
INSERT INTO `user_attention` VALUES ('mike','Amy'),('test','mike'),('test','John'),('Amy','mike'),('Amy','Nancy'),('Amy','John'),('Nancy','test'),('Nancy','John'),('John','mike'),('','Amy'),('mike','test');
/*!40000 ALTER TABLE `user_attention` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_comment`
--

DROP TABLE IF EXISTS `user_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_comment` (
  `c_id` int(8) NOT NULL AUTO_INCREMENT,
  `comment_id` int(8) NOT NULL,
  `comment_content` varchar(255) NOT NULL,
  `comment_user_id` int(8) NOT NULL,
  `comment_time` varchar(64) DEFAULT NULL,
  `user_name` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_comment`
--

LOCK TABLES `user_comment` WRITE;
/*!40000 ALTER TABLE `user_comment` DISABLE KEYS */;
INSERT INTO `user_comment` VALUES (1,1,'Good',2,'20170505','Amy'),(2,2,'Bad',2,'20170101','Nancy'),(3,1,'Good',4,'20160102','Amy'),(4,1,'Very Good',5,'20170203','mike'),(5,2,'Not Good',5,'20170303','Amy');
/*!40000 ALTER TABLE `user_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_img`
--

DROP TABLE IF EXISTS `user_img`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_img` (
  `i_id` int(8) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(32) NOT NULL,
  `user_img_url` varchar(255) DEFAULT 'C:\\images\\img1.jpg',
  PRIMARY KEY (`i_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_img`
--

LOCK TABLES `user_img` WRITE;
/*!40000 ALTER TABLE `user_img` DISABLE KEYS */;
INSERT INTO `user_img` VALUES (1,'test','C:\\images\\img1.jpg'),(2,'mike','C:\\images\\img1.jpg'),(3,'Amy','C:\\images\\img1.jpg'),(4,'Nancy','C:\\images\\img1.jpg'),(5,'John','C:\\images\\img1.jpg'),(6,'Blogger1','C:\\images\\img1.jpg'),(7,'Manager1','C:\\images\\img1.jpg');
/*!40000 ALTER TABLE `user_img` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_praise`
--

DROP TABLE IF EXISTS `user_praise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_praise` (
  `p_id` int(8) NOT NULL AUTO_INCREMENT,
  `article_id` int(5) NOT NULL,
  `praise_amount` int(10) DEFAULT NULL,
  `praise_user_id` int(8) NOT NULL,
  `praise_time` varchar(64) DEFAULT NULL,
  `user_name` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_praise`
--

LOCK TABLES `user_praise` WRITE;
/*!40000 ALTER TABLE `user_praise` DISABLE KEYS */;
INSERT INTO `user_praise` VALUES (2,3,10,3,'20170101','mike'),(3,4,10,3,'20170101','mike'),(4,1,10,2,'20170201','Amy'),(5,6,10,5,'20160501','Amy'),(6,4,10,3,'20170101','Nancy');
/*!40000 ALTER TABLE `user_praise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_rank`
--

DROP TABLE IF EXISTS `user_rank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_rank` (
  `rank_id` int(5) NOT NULL AUTO_INCREMENT,
  `user_rank_id` int(3) NOT NULL,
  `rank_name` varchar(32) NOT NULL,
  `rank_description` varchar(100) NOT NULL,
  `user_name` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`rank_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_rank`
--

LOCK TABLES `user_rank` WRITE;
/*!40000 ALTER TABLE `user_rank` DISABLE KEYS */;
INSERT INTO `user_rank` VALUES (1,1,'Visitor','Can see and do some comments','test'),(2,1,'Visitor','Can see and do some comments','mike'),(3,1,'Visitor','Can see and do some comments','Amy'),(4,1,'Visitor','Can see and do some comments','Nancy'),(5,1,'Visitor','Can see and do some comments','John'),(6,2,'Blogger','Can manage and do some comments','Blogger1'),(7,3,'Manager','Can manage and do some comments','Manager1');
/*!40000 ALTER TABLE `user_rank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_reward`
--

DROP TABLE IF EXISTS `user_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_reward` (
  `r_id` int(8) NOT NULL AUTO_INCREMENT,
  `user_id` int(8) NOT NULL,
  `reward_amound` int(10) DEFAULT NULL,
  `reward_user_id` int(8) NOT NULL,
  `reward_time` varchar(64) DEFAULT NULL,
  `user_name` varchar(32) DEFAULT NULL,
  `reward_user_name` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`r_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_reward`
--

LOCK TABLES `user_reward` WRITE;
/*!40000 ALTER TABLE `user_reward` DISABLE KEYS */;
INSERT INTO `user_reward` VALUES (1,2,10,3,'20170101','mike','mike'),(2,3,10,5,'20170201','Amy','Amy'),(3,3,10,2,'20170105','Amy','Amy'),(4,4,10,2,'20170401','Nancy','Nancy'),(5,4,10,5,'20170301','Nancy','Nancy'),(6,5,10,2,'20170108','John','John'),(7,5,20,4,'20170311','John','John');
/*!40000 ALTER TABLE `user_reward` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_name` varchar(20) DEFAULT NULL,
  `user_pwd` varchar(25) DEFAULT NULL,
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('a','a'),('b','b'),('sss','sss'),('','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-19 22:05:39
